package com.prueba1.prueba1.dao;

import org.springframework.data.repository.CrudRepository;

import com.prueba1.prueba1.domain.Revista;

public interface RevistaDao extends CrudRepository<Revista, Long> {

}
